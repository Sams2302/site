using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace C__MVC.Models
{
    public class ItemPedido
    {
        List<Pedido> listaDeItens = new List<Pedido>();

        public List<Pedido> Listar() {
            return listaDeItens;
        }

        public void Adicionar(Pedido pedidoNovo) {
            listaDeItens.Add(pedidoNovo);
       }

       public double Calcular() {
           double total = 0;

           for (int i=0; i < listaDeItens.Count; i++)
           {
              total = listaDeItens[i].valor_unitario + total;
           }

           return total;
       }
    }
}