using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace C__MVC.Models
{
    public class Pedido
    {
       public string descricao {get; set;}
       public double valor_unitario {get; set;}
       public int quantidade {get; set;}

       public void Adicionar(Pedido pedidoNovo) {
            listaDeItens.Add(pedidoNovo);
        }
        List<Pedido> listaDeItens = new List<Pedido>();

        public List<Pedido> Listar() {
            return listaDeItens;
        }

        public double Calcular() {
           double total = 0;

           for (int i=0; i < listaDeItens.Count; i++)
           {
              total = listaDeItens[i].valor_unitario * listaDeItens[i].quantidade + total;
           }

           return total;
       }
    }
}